Ujjain - Omkareshwar Taxi Service
Simple one-page demo website.

Files:
- index.html : main page
- styles.css : styles
- script.js  : client-side handling (stores bookings/reviews in browser localStorage)
- images/*   : small SVG assets (logo and car illustrations)

Notes:
- This is an offline demo. Bookings/reviews are stored in the visitor's browser (localStorage).
- To accept bookings or show reviews across devices you need a server or connect to Google Business APIs.
- You can replace the SVGs in /images with real photos (keep same filenames) if you want real car photos.
