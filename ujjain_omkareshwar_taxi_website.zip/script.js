// Simple client-side booking and review handling using localStorage
function book(car, price){
  document.querySelector('#bookingForm select').value = car + ' — ₹' + price;
  window.scrollTo({top: document.querySelector('#contact').offsetTop, behavior:'smooth'});
}
function submitBooking(e){
  e.preventDefault();
  const f = e.target;
  const data = {
    pickup: f.pickup.value,
    drop: f.drop.value,
    name: f.name.value,
    phone: f.phone.value,
    car: f.car.value,
    time: new Date().toISOString()
  };
  const arr = JSON.parse(localStorage.getItem('bookings')||'[]');
  arr.push(data);
  localStorage.setItem('bookings', JSON.stringify(arr));
  renderBookings();
  f.reset();
  alert('Booking saved locally — a real site would send this to your server or WhatsApp.');
}
function renderBookings(){
  const arr = JSON.parse(localStorage.getItem('bookings')||'[]');
  const el = document.getElementById('bookingsList');
  if(!arr.length){ el.innerHTML = '<em>No bookings yet.</em>'; return; }
  el.innerHTML = arr.map(b=>`<div class="bk"><strong>${b.car}</strong> — ${b.name} • ${b.phone} <br/> ${b.pickup} → ${b.drop} <br/><small>${new Date(b.time).toLocaleString()}</small></div>`).join('<hr/>');
}
function submitReview(e){
  e.preventDefault();
  const f = e.target;
  const data = {name:f.rname.value, rating: f.rating.value, text:f.text.value, time:new Date().toISOString()};
  const arr = JSON.parse(localStorage.getItem('reviews')||'[]');
  arr.unshift(data);
  localStorage.setItem('reviews', JSON.stringify(arr));
  renderReviews();
  f.reset();
  alert('Review saved locally. To show on other devices you need a server or Google Business.');
}
function renderReviews(){
  const arr = JSON.parse(localStorage.getItem('reviews')||'[]');
  const el = document.getElementById('reviews');
  if(!arr.length){ el.innerHTML = '<em>No reviews yet.</em>'; return; }
  el.innerHTML = arr.map(r=>`<div class="rv"><strong>${r.name}</strong> — ${r.rating}★ <div>${r.text}</div><small>${new Date(r.time).toLocaleString()}</small></div>`).join('<hr/>');
}
document.addEventListener('DOMContentLoaded', ()=>{ renderBookings(); renderReviews(); });
